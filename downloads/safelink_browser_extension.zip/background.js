chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    console.log("Intercepted URL:", details.url);
    // Call API
    fetch('http://localhost:8000/api/verify_url', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: details.url })
    })
    .then((response) => response.json())
    .then((data) => {
      console.log("Risk Score:", data.riskScore);
    })
    .catch((err) => console.error('Error:', err));
  }, 
  { urls: ["<all_urls>"] },
  []
);
