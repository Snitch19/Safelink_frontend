document.getElementById("checkButton").addEventListener("click", () => {
    const url = document.getElementById("urlInput").value;
    fetch('http://localhost:8000/api/verify_url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
    })
    .then((response) => response.json())
    .then((data) => {
        document.getElementById("result").innerText = `Risk Score: ${data.riskScore}`;
    })
    .catch((error) => console.error(error));
});
